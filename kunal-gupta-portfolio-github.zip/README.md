# Kunal Gupta Portfolio

This repository is ready for GitHub Pages.

## GitHub Pages
1. Upload `index.html` to a GitHub repository.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select the `main` branch and `/ (root)`.
5. Save.

Your site will then be available at:

`https://YOUR-GITHUB-USERNAME.github.io/REPOSITORY-NAME/`
